const socket = io();
let username = "";
let roomCode = "";

function createRoom() {
  username = document.getElementById("username").value.trim();
  if (!username) return alert("Enter a username");
  socket.emit("createRoom", username);
}

function joinRoom() {
  username = document.getElementById("username").value.trim();
  roomCode = document.getElementById("roomInput").value.trim();
  if (!username || !roomCode) return alert("Enter username and room code");
  socket.emit("joinRoom", { roomCode, username });
}

socket.on("roomCreated", (code) => {
  roomCode = code;
  startChat();
  addSystemMessage(`Room created! Share this code: ${code}`);
});

socket.on("roomJoined", (code) => {
  roomCode = code;
  startChat();
});

socket.on("errorMessage", (msg) => {
  document.getElementById("error").innerText = msg;
});

socket.on("systemMessage", (msg) => {
  addSystemMessage(msg);
});

socket.on("receiveMessage", (data) => {
  addMessage(
    data.username,
    data.message,
    data.time,
    data.username === username
  );
});

function startChat() {
  document.getElementById("login").style.display = "none";
  document.getElementById("chat").style.display = "flex";
  document.getElementById("roomDisplay").innerText = "Room: " + roomCode;
}

function leaveRoom() {
  location.reload();
}

function sendMessage() {
  const input = document.getElementById("messageInput");
  const message = input.value.trim();
  if (!message) return;

  socket.emit("sendMessage", { roomCode, message, username });
  input.value = "";
}

function addMessage(user, msg, time, isMine) {
  const messages = document.getElementById("messages");
  const div = document.createElement("div");
  div.classList.add("message");
  div.classList.add(isMine ? "myMessage" : "otherMessage");

  div.innerHTML = `<div class="msgUser">${user}</div>
                   <div>${msg}</div>
                   <div class="timestamp">${time}</div>`;

  messages.appendChild(div);
  messages.scrollTop = messages.scrollHeight;
}

function addSystemMessage(msg) {
  const messages = document.getElementById("messages");
  const div = document.createElement("div");
  div.classList.add("systemMessage");
  div.innerText = msg;
  messages.appendChild(div);
  messages.scrollTop = messages.scrollHeight;
}

document
  .getElementById("messageInput")
  .addEventListener("keypress", function (e) {
    if (e.key === "Enter") sendMessage();
  });
