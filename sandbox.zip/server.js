const express = require("express");
const http = require("http");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server);

// Serve frontend
app.use(express.static("public"));

// Simple function to generate 6-digit room code
function generateCode() {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

// Store rooms in memory
const rooms = {};

io.on("connection", (socket) => {
  console.log("User connected");

  socket.on("createRoom", (username) => {
    const code = generateCode();
    rooms[code] = { users: [username] };
    socket.join(code);
    socket.emit("roomCreated", code);
  });

  socket.on("joinRoom", ({ roomCode, username }) => {
    if (rooms[roomCode]) {
      rooms[roomCode].users.push(username);
      socket.join(roomCode);
      socket.emit("roomJoined", roomCode);
      io.to(roomCode).emit("systemMessage", `${username} joined the room`);
    } else {
      socket.emit("errorMessage", "Room does not exist");
    }
  });

  socket.on("sendMessage", ({ roomCode, message, username }) => {
    const time = new Date().toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit",
    });
    io.to(roomCode).emit("receiveMessage", { username, message, time });
  });
});

server.listen(3000, () => {
  console.log("Server running on port 3000");
});
